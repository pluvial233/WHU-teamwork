from flask import Flask, render_template, request, redirect, url_for, session # type: ignore
from flask_sqlalchemy import SQLAlchemy # type: ignore
import os
import time
import webbrowser
import threading
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'book_management_system_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///books.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# 数据库模型定义
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), default='user')  # 'admin' or 'user'
    borrow_records = db.relationship('BorrowRecord', backref='user', lazy=True)

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50))
    isbn = db.Column(db.String(20), unique=True)
    stock = db.Column(db.Integer, default=1)
    borrow_records = db.relationship('BorrowRecord', backref='book', lazy=True)

class BorrowRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    borrow_date = db.Column(db.DateTime, default=datetime.utcnow)
    due_date = db.Column(db.DateTime, default=lambda: datetime.utcnow() + timedelta(days=14))
    return_date = db.Column(db.DateTime, nullable=True)
    fine = db.Column(db.Float, default=0.0)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)

# 创建数据库表
with app.app_context():
    db.create_all()
    # 创建默认用户（如果不存在）
    if not User.query.filter_by(username='admin').first():
        admin = User(username='admin', password='admin', role='admin')
        db.session.add(admin)
    if not User.query.filter_by(username='user').first():
        test_user = User(username='user', password='user', role='user')
        db.session.add(test_user)
    db.session.commit()

# 路由定义
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # 检查用户名是否已存在
        if User.query.filter_by(username=username).first():
            return render_template('register.html', error='用户名已存在')
        
        # 创建新用户
        new_user = User(username=username, password=password, role='user')
        db.session.add(new_user)
        db.session.commit()
        
        return render_template('register.html', success='注册成功，请登录')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            session['role'] = user.role
            return redirect(url_for('dashboard'))
        # 登录失败，显示错误信息
        return render_template('login.html', error='用户名或密码错误')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('role', None)
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    # 获取当前用户的借阅记录
    borrow_records = BorrowRecord.query.filter_by(user_id=session['user_id']).all()
    return render_template('dashboard.html', borrow_records=borrow_records)

@app.route('/search_books', methods=['POST'])
def search_books():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    query = request.form['search_query']
    # 搜索书名或作者包含查询词的图书
    search_results = Book.query.filter(
        db.or_(Book.title.like(f'%{query}%'), Book.author.like(f'%{query}%'))
    ).all()
    # 获取借阅记录用于页面显示
    borrow_records = BorrowRecord.query.filter_by(user_id=session['user_id']).all()
    return render_template('dashboard.html', search_results=search_results, borrow_records=borrow_records)

@app.route('/borrow_book/<int:book_id>')
def borrow_book(book_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    book = Book.query.get_or_404(book_id)
    # 检查库存
    if book.stock <= 0:
        return redirect(url_for('dashboard'))
    # 创建借阅记录
    new_record = BorrowRecord(user_id=session['user_id'], book_id=book_id)
    db.session.add(new_record)
    # 减少库存
    book.stock -= 1
    db.session.commit()
    return redirect(url_for('dashboard'))

@app.route('/return_book/<int:record_id>')
def return_book(record_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    record = BorrowRecord.query.get_or_404(record_id)
    # 检查是否是当前用户的借阅记录
    if record.user_id != session['user_id']:
        return redirect(url_for('dashboard'))
    # 更新归还日期
    record.return_date = datetime.utcnow()
    # 增加库存
    book = Book.query.get(record.book_id)
    book.stock += 1
    db.session.commit()
    return redirect(url_for('dashboard'))

def open_browser_after_delay():
    # 等待服务器启动
    time.sleep(2)
    webbrowser.open('http://127.0.0.1:5000/')

if __name__ == '__main__':
    # 在单独线程中启动浏览器，避免阻塞服务器启动
    threading.Thread(target=open_browser_after_delay).start()
    app.run(debug=True)