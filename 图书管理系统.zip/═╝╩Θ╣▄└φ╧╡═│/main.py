import threading
import os
from ctypes import windll
# 移除 from PIL import Image

# 多线程装饰器
def threaded(func):
    def wrapper(*args, **kwargs):
        thread = threading.Thread(target=func, args=args, kwargs=kwargs)
        thread.start()
        return thread
    return wrapper

# 用户类
class User:
    def __init__(self, username, password, role='user'):
        self.username = username
        self.password = password
        self.role = role
        self.borrow_history = []

# 图书类
class Book:
    def __init__(self, id, title, author, category, is_borrowed=False):
        self.id = id
        self.title = title
        self.author = author
        self.category = category
        self.is_borrowed = is_borrowed

# 图书管理系统类
class LibraryManagementSystem:
    def __init__(self):
        self.users = {}
        self.books = {}
        self.next_book_id = 1

    def register_user(self, username, password, role='user'):
        if username in self.users:
            print('用户名已存在')
            return False
        self.users[username] = User(username, password, role)
        return True

    def login(self, username, password):
        user = self.users.get(username)
        if user and user.password == password:
            return user
        return None

    def add_book(self, title, author, category):
        book = Book(self.next_book_id, title, author, category)
        self.books[self.next_book_id] = book
        self.next_book_id += 1
        return book.id

    def search_books(self, keyword):
        result = []
        for book in self.books.values():
            if keyword.lower() in book.title.lower() or keyword.lower() in book.author.lower():
                result.append(book)
        return result

    def borrow_book(self, user, book_id):
        book = self.books.get(book_id)
        if book and not book.is_borrowed:
            book.is_borrowed = True
            user.borrow_history.append(book_id)
            return True
        return False

    def return_book(self, user, book_id, return_date):
        book = self.books.get(book_id)
        if book and book.is_borrowed and book_id in user.borrow_history:
            book.is_borrowed = False
            # 假设借阅期限为 30 天
            borrow_date = self.get_borrow_date(user, book_id)
            overdue_days = (return_date - borrow_date).days - 30
            if overdue_days > 0:
                fine = overdue_days * 1  # 每天罚款 1 元
                print(f'逾期 {overdue_days} 天，需缴纳罚款 {fine} 元')
            return True
        return False

    def get_borrow_date(self, user, book_id):
        # 这里简单返回一个固定日期，实际需要记录借阅日期
        from datetime import datetime
        return datetime.now()

    @threaded
    def backup_data(self):
        import json
        data = {
            'users': {},
            'books': {}
        }
        for username, user in self.users.items():
            data['users'][username] = {
                'password': user.password,
                'role': user.role,
                'borrow_history': user.borrow_history
            }
        for book_id, book in self.books.items():
            data['books'][book_id] = {
                'title': book.title,
                'author': book.author,
                'category': book.category,
                'is_borrowed': book.is_borrowed
            }
        with open('backup.json', 'w') as f:
            json.dump(data, f)

    @threaded
    def restore_data(self):
        import json
        try:
            with open('backup.json', 'r') as f:
                data = json.load(f)
            self.users = {}
            self.books = {}
            for username, user_data in data['users'].items():
                user = User(username, user_data['password'], user_data['role'])
                user.borrow_history = user_data['borrow_history']
                self.users[username] = user
            for book_id, book_data in data['books'].items():
                book = Book(int(book_id), book_data['title'], book_data['author'], book_data['category'], book_data['is_borrowed'])
                self.books[int(book_id)] = book
            print('数据恢复成功')
        except FileNotFoundError:
            print('未找到备份文件')

    @threaded
    def handle_feedback(self, user, feedback):
        if user in self.users:
            with open('feedback.txt', 'a') as f:
                f.write(f'{user.username}: {feedback}\n')
            print('反馈提交成功')
            # GDI 图形处理示例：截取屏幕并保存
            hwnd = win32gui.GetDesktopWindow() # type: ignore
            width = windll.user32.GetSystemMetrics(0)
            height = windll.user32.GetSystemMetrics(1)
            hwndDC = win32gui.GetWindowDC(hwnd) # type: ignore
            mfcDC = win32ui.CreateDCFromHandle(hwndDC) # type: ignore
            saveDC = mfcDC.CreateCompatibleDC()
            saveBitMap = win32ui.CreateBitmap() # type: ignore
            saveBitMap.CreateCompatibleBitmap(mfcDC, width, height)
            saveDC.SelectObject(saveBitMap)
            saveDC.BitBlt((0, 0), (width, height), mfcDC, (0, 0), win32con.SRCCOPY) # type: ignore
            saveBitMap.SaveBitmapFile(saveDC, 'screenshot.bmp')
            win32gui.DeleteObject(saveBitMap.GetHandle()) # type: ignore
            saveDC.DeleteDC()
            mfcDC.DeleteDC()
            win32gui.ReleaseDC(hwnd, hwndDC) # type: ignore
        else:
            print('用户不存在')
        if user in self.users:
            with open('feedback.txt', 'a') as f:
                f.write(f'{user.username}: {feedback}\n')
            print('反馈提交成功')
        else:
            print('用户不存在')

if __name__ == '__main__':
    library = LibraryManagementSystem()
    # 示例操作
    library.register_user('admin', 'admin123', 'admin')
    library.register_user('user1', 'user123')
    book_id = library.add_book('Python编程从入门到实践', 'Eric Matthes', '编程')
    user = library.login('user1', 'user123')
    if user:
        if library.borrow_book(user, book_id):
            print('借阅成功')
        else: '借阅失败'
